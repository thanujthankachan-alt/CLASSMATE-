import { detectConflicts } from './conflictService.js';
import { WEEK_DAYS, normalizeTime, timeToMinutes } from '../utils/timeUtils.js';
import { generateSourceTimetable, getAllSourceTimetableSessions } from '../data/sourceTimetables.js';

function normalizeAppData(appData = {}) {
  const normalizeCollection = (collection = [], key) => (Array.isArray(collection) ? collection.map((item, index) => {
    if (!item || typeof item !== 'object') return item;

    const nextItem = { ...item };
    const generatedId = nextItem.id ?? nextItem.code ?? nextItem.number ?? nextItem.name ?? nextItem.email ?? `${key}-${index + 1}`;
    nextItem.id = generatedId;

    if (key === 'subjects') {
      nextItem.duration = Number(nextItem.duration ?? nextItem.periods ?? nextItem.weeklyPeriods ?? 1);
      nextItem.requiresLab = Boolean(nextItem.requiresLab || nextItem.sessionType === 'Lab' || nextItem.type === 'Lab');
      nextItem.weeklyPeriods = Number(nextItem.weeklyPeriods ?? nextItem.periods ?? nextItem.duration ?? 1);
    }

    if (key === 'rooms') {
      nextItem.capacity = Number(nextItem.capacity ?? nextItem.maxCapacity ?? 30);
      if (!nextItem.type && nextItem.isLab) nextItem.type = 'Lab';
    }

    if (key === 'classes') {
      nextItem.studentCount = Number(nextItem.studentCount ?? nextItem.students ?? 0);
    }

    return nextItem;
  }) : []);

  return {
    classes: normalizeCollection(appData.classes, 'classes'),
    subjects: normalizeCollection(appData.subjects, 'subjects'),
    faculty: normalizeCollection(appData.faculty, 'faculty'),
    rooms: normalizeCollection(appData.rooms, 'rooms'),
    constraints: Array.isArray(appData.constraints) ? appData.constraints : [],
    timeSlots: Array.isArray(appData.timeSlots) ? appData.timeSlots : [],
    breaks: Array.isArray(appData.breaks) ? appData.breaks : [],
    settings: appData.settings || {}
  };
}

function buildDefaultSlots() {
  const startTimes = ['09:00', '10:00', '11:00', '13:00', '14:00', '15:00'];
  const endTimes = ['09:55', '10:55', '11:55', '13:55', '14:55', '15:55'];
  const slots = [];

  WEEK_DAYS.forEach((day, dayIndex) => {
    startTimes.forEach((startTime, index) => {
      slots.push({
        id: `${day}-${index + 1}`,
        day,
        dayIndex,
        startTime,
        endTime: endTimes[index],
        periodNumber: index + 1,
        type: 'lecture'
      });
    });
  });

  return slots;
}

function parseSlot(slot) {
  if (!slot) return null;
  if (typeof slot === 'string') {
    const match = slot.match(/^([A-Za-z]+)\s*[:\-]\s*(\d{1,2}:\d{2})\s*[-–]\s*(\d{1,2}:\d{2})$/i);
    if (match) {
      return {
        id: slot,
        day: match[1],
        dayIndex: WEEK_DAYS.indexOf(match[1]) >= 0 ? WEEK_DAYS.indexOf(match[1]) : 0,
        startTime: normalizeTime(match[2]),
        endTime: normalizeTime(match[3]),
        periodNumber: 1,
        type: 'lecture'
      };
    }
    return null;
  }

  if (slot.slot && !slot.day && !slot.startTime && !slot.endTime) {
    const timeMatch = String(slot.slot).match(/(\d{1,2}:\d{2})\s*(?:AM|PM)?\s*[-–]\s*(\d{1,2}:\d{2})\s*(?:AM|PM)?/i);
    if (timeMatch) {
      return {
        id: slot.id || `${slot.slot}`,
        day: 'Monday',
        dayIndex: 0,
        startTime: normalizeTime(timeMatch[1]),
        endTime: normalizeTime(timeMatch[2]),
        periodNumber: slot.id || 1,
        type: 'lecture'
      };
    }
  }

  return {
    id: slot.id || `${slot.day || 'Monday'}-${slot.periodNumber || slot.startTime || '09:00'}`,
    day: slot.day || 'Monday',
    dayIndex: slot.dayIndex ?? WEEK_DAYS.indexOf(slot.day || 'Monday'),
    startTime: normalizeTime(slot.startTime || slot.start || '09:00'),
    endTime: normalizeTime(slot.endTime || slot.end || '09:55'),
    periodNumber: slot.periodNumber || 1,
    type: slot.type || 'lecture'
  };
}

function expandGenericTimeSlots(rawSlots) {
  if (!Array.isArray(rawSlots) || rawSlots.length === 0) return [];
  const genericSlotItems = rawSlots.filter((slot) => slot && !slot.day && !slot.startTime && !slot.endTime && slot.slot);
  if (genericSlotItems.length === 0) return rawSlots;

  const expanded = [];
  const parsedSlots = genericSlotItems.map((slot) => {
    const timeMatch = String(slot.slot).match(/(\d{1,2}:\d{2})\s*(?:AM|PM)?\s*[-–]\s*(\d{1,2}:\d{2})\s*(?:AM|PM)?/i);
    if (!timeMatch) return null;
    return {
      startTime: timeMatch[1],
      endTime: timeMatch[2]
    };
  }).filter(Boolean);

  WEEK_DAYS.forEach((day) => {
    parsedSlots.forEach((slot, index) => {
      expanded.push({
        id: `${day}-${index + 1}`,
        day,
        dayIndex: WEEK_DAYS.indexOf(day),
        startTime: slot.startTime,
        endTime: slot.endTime,
        periodNumber: index + 1,
        type: 'lecture'
      });
    });
  });

  return expanded;
}


function getSlotsForData(appData) {
  const rawSlots = Array.isArray(appData.timeSlots) && appData.timeSlots.length > 0 ? appData.timeSlots : buildDefaultSlots();
  const expandedSlots = expandGenericTimeSlots(rawSlots);
  return expandedSlots.map(parseSlot).filter(Boolean);
}

function getClassById(appData, classId) {
  return (appData.classes || []).find((item) => String(item.id) === String(classId));
}

function getSubjectById(appData, subjectId) {
  return (appData.subjects || []).find((item) => String(item.id) === String(subjectId));
}

function getRoomById(appData, roomId) {
  return (appData.rooms || []).find((item) => String(item.id) === String(roomId));
}

function getFacultyById(appData, facultyId) {
  return (appData.faculty || []).find((item) => String(item.id) === String(facultyId));
}

function matchesAvailability(value, day) {
  if (!value) return true;

  const values = Array.isArray(value) ? value : [value];
  const dayName = String(day).toLowerCase();
  const placeholderPattern = /(see source timetable|not provided|n\/a|all days|every day|daily|weekday|weekdays|monday-friday|mon-fri)/i;
  const dayAliases = {
    mon: 'monday',
    tue: 'tuesday',
    wed: 'wednesday',
    thu: 'thursday',
    fri: 'friday',
    sat: 'saturday',
    sun: 'sunday'
  };

  return values.some((entry) => {
    if (typeof entry === 'string') {
      const normalized = String(entry).toLowerCase();
      if (placeholderPattern.test(normalized)) return true;
      if (normalized.includes(dayName)) return true;
      const aliasMatch = Object.entries(dayAliases).some(([alias, fullDay]) => normalized.includes(alias) && dayName === fullDay);
      if (aliasMatch) return true;
      return normalized.includes(dayName.slice(0, 3));
    }
    if (typeof entry === 'object') {
      return entry.day === day || String(entry).toLowerCase().includes(dayName);
    }
    return false;
  });
}

function getFacultyAvailability(faculty, day) {
  if (!faculty || !faculty.availability) return true;
  return matchesAvailability(faculty.availability, day);
}

function getRoomAvailability(room, day) {
  if (!room || !room.availability) return true;
  return matchesAvailability(room.availability, day);
}

function getClassAvailability(classItem, day) {
  if (!classItem || !classItem.availability) return true;
  return matchesAvailability(classItem.availability, day);
}

function getBreaks(appData) {
  const breaks = Array.isArray(appData.breaks) ? appData.breaks : [];
  if (breaks.length > 0) {
    return breaks.filter((b) => b && (b.startTime || b.start) && (b.endTime || b.end)).map((b) => ({
      day: b.day || 'Monday',
      startTime: b.startTime || b.start,
      endTime: b.endTime || b.end
    }));
  }
  return (appData.constraints || []).filter((c) => c && (c.startTime || c.start) && (c.endTime || c.end)).map((c) => ({
    day: c.day || 'Monday',
    startTime: c.startTime || c.start,
    endTime: c.endTime || c.end
  }));
}

function isBreakBlocked(entry, appData) {
  const breaks = getBreaks(appData);
  return breaks.some((period) => {
    if (!period || !period.day || !period.startTime || !period.endTime) return false;
    return period.day === entry.day && entry.startMinutes < timeToMinutes(period.endTime) && timeToMinutes(period.startTime) < entry.endMinutes;
  });
}

function canPlaceEntry(rawEntry, entries, appData) {
  const rawSubject = getSubjectById(appData, rawEntry.subjectId);
  const isRawLab = rawEntry.subjectType === 'Lab' || Boolean(rawSubject?.requiresLab) || (rawEntry.subjectName || '').toLowerCase().includes('lab');

  for (let i = 0; i < entries.length; i += 1) {
    const existing = entries[i];
    if (existing.day === rawEntry.day) {
      const overlaps = rawEntry.startMinutes < existing.endMinutes && existing.startMinutes < rawEntry.endMinutes;
      if (overlaps) {
        if (String(existing.classId) === String(rawEntry.classId)) return false;
        if (String(existing.facultyId) === String(rawEntry.facultyId)) return false;
        if (String(existing.roomId) === String(rawEntry.roomId)) return false;

        const existingSubject = getSubjectById(appData, existing.subjectId);
        const isExistingLab = existing.subjectType === 'Lab' || Boolean(existingSubject?.requiresLab) || (existing.subjectName || '').toLowerCase().includes('lab');
        if (isRawLab && isExistingLab && String(existing.classId) !== String(rawEntry.classId)) {
          // Single DCA Lab constraint: only one class can be in the Computer Lab at any time slot
          return false;
        }
      }
    }
  }

  const room = getRoomById(appData, rawEntry.roomId);
  const classItem = getClassById(appData, rawEntry.classId);
  const facultyMember = getFacultyById(appData, rawEntry.facultyId);

  if (room && classItem) {
    const roomCapacity = Number(room.capacity ?? room.maxCapacity ?? 0);
    const classSize = Number(classItem.studentCount ?? classItem.students ?? 0);
    if (roomCapacity > 0 && classSize > roomCapacity) return false;
  }

  if (room && isRawLab && !(room.isLab || room.type === 'Lab')) return false;

  if (facultyMember && facultyMember.maxPeriodsPerDay) {
    let countToday = 0;
    for (let i = 0; i < entries.length; i += 1) {
      if (String(entries[i].facultyId) === String(facultyMember.id) && entries[i].day === rawEntry.day) {
        countToday += 1;
      }
    }
    if (countToday + 1 > Number(facultyMember.maxPeriodsPerDay)) return false;
  }

  if (isBreakBlocked(rawEntry, appData)) return false;

  return true;
}

function isSubjectForClass(subject, classItem) {
  if (!subject || !classItem) return true;
  if (subject.classId && String(subject.classId) === String(classItem.id)) return true;
  if (subject.className && subject.className === classItem.name) return true;

  const className = (classItem.name || '').toUpperCase();
  const subjectCode = (subject.code || '').toUpperCase();

  if (className.includes('MCA')) {
    if (subjectCode.startsWith('BCP')) return false;
    return true;
  }
  if (className.includes('BCA')) {
    if (subjectCode.startsWith('20MCA')) return false;
    return true;
  }

  if (subject.department && classItem.department) {
    return subject.department.toLowerCase() === classItem.department.toLowerCase();
  }

  return true;
}

function getCandidateSlots(session, appData) {
  const slots = getSlotsForData(appData);
  const subject = getSubjectById(appData, session.subjectId);
  const duration = Number(subject?.duration || session.duration || 1);
  const candidates = [];

  slots.forEach((slot, index) => {
    if (duration === 1) {
      candidates.push({
        ...slot,
        startTime: slot.startTime,
        endTime: slot.endTime,
        duration: 1
      });
      return;
    }

    const block = slots.slice(index, index + duration);
    if (block.length < duration) return;
    candidates.push({
      ...block[0],
      id: `${block[0].id}-${block[block.length - 1].id}`,
      day: block[0].day,
      dayIndex: block[0].dayIndex,
      startTime: block[0].startTime,
      endTime: block[block.length - 1].endTime,
      duration,
      block
    });
  });

  return candidates;
}

function getQualifiedFaculty(session, appData) {
  const subject = getSubjectById(appData, session.subjectId);
  return (appData.faculty || []).filter((facultyMember) => {
    if (subject && Array.isArray(subject.facultyIds) && subject.facultyIds.length > 0 && !subject.facultyIds.includes(facultyMember.id)) {
      return false;
    }

    const matchingFacultyNames = [];
    if (subject && typeof subject.faculty === 'string') {
      matchingFacultyNames.push(...subject.faculty.split(/[\/|,]/).map((name) => name.trim()).filter(Boolean));
    }
    if (subject && Array.isArray(subject.faculty)) {
      matchingFacultyNames.push(...subject.faculty.map((name) => String(name).trim()).filter(Boolean));
    }

    if (matchingFacultyNames.length > 0) {
      const normalizedMemberName = facultyMember.name.toLowerCase();
      return matchingFacultyNames.some((candidate) => {
        const matchText = candidate.toLowerCase();
        return normalizedMemberName.includes(matchText) || matchText.includes(normalizedMemberName);
      });
    }

    return true;
  });
}

function getSessionName(subject) {
  if (!subject) return 'Subject';
  return subject.name || subject.code || 'Subject';
}

function getQualifiedRooms(session, appData) {
  const subject = getSubjectById(appData, session.subjectId);
  const classItem = getClassById(appData, session.classId);

  return (appData.rooms || []).filter((room) => {
    if (classItem) {
      const roomCapacity = Number(room.capacity ?? room.maxCapacity ?? 0);
      const classSize = Number(classItem.studentCount ?? classItem.students ?? 0);
      if (roomCapacity > 0 && classSize > roomCapacity) return false;
    }

    if (subject?.requiresLab && !(room.isLab || room.type === 'Lab')) return false;
    if (Array.isArray(subject?.allowedRoomTypes) && subject.allowedRoomTypes.length > 0 && !subject.allowedRoomTypes.includes(room.type)) return false;
    return true;
  });
}

function getSoftScore(entry, appData, option = {}) {
  let score = 0;
  const room = getRoomById(appData, entry.roomId);
  const faculty = getFacultyById(appData, entry.facultyId);

  if (entry.day === option.dayPreference) score += 8;
  if (room && (room.name === option.preferredRoom || room.type === option.roomPreference)) score += 10;
  if (faculty && option.preferredFaculty && faculty.name.toLowerCase().includes(option.preferredFaculty.toLowerCase())) score += 12;
  if (entry.subjectType === 'Lab') score += 8;

  return score;
}

export function generateTimetable(appData, options = {}) {
  const data = normalizeAppData(appData);

  const sourceSessions = getAllSourceTimetableSessions();

  const mappedEntries = sourceSessions.map((session, idx) => {
    const classObj = (data.classes || []).find((c) => c.name === session.className) || { id: session.className, name: session.className, room: session.room };
    const facultyObj = (data.faculty || []).find((f) => f.name === session.faculty);
    const roomObj = (data.rooms || []).find((r) => r.number === session.room || r.name === session.room);
    const subjectObj = (data.subjects || []).find((s) => s.name === session.subject || s.code === session.subject);

    const isLab = (session.room === 'Computer Lab') || (session.subject || '').toLowerCase().includes('lab');
    const isTutorial = (session.subject || '').endsWith('(T)') || (session.subject || '').toLowerCase().includes('tutorial');
    const isRemedial = (session.subject || '').endsWith('(R)') || (session.subject || '').toLowerCase().includes('remedial');
    const isActivity = (session.subject || '').includes('PLACEMENT') || (session.subject || '').includes('PROJECT') || (session.subject || '').includes('MENTOR') || (session.subject || '').includes('LIBRARY') || (session.subject || '').includes('MOOC');

    let subjectType = 'Theory';
    if (isLab) subjectType = 'Lab';
    else if (isTutorial) subjectType = 'Tutorial';
    else if (isRemedial) subjectType = 'Remedial';
    else if (isActivity) subjectType = 'Activity';

    const startMin = timeToMinutes(session.start);
    const endMin = timeToMinutes(session.end);
    const duration = Math.max(1, Math.round((endMin - startMin) / 55));

    return {
      id: `session-${session.className}-${session.day}-${session.start}-${idx + 1}`,
      classId: classObj.id || session.className,
      className: session.className,
      department: session.department || classObj.department || 'Computer Applications',
      semester: session.semester || classObj.semester || 'ODD',
      subjectId: subjectObj?.id || session.subject,
      subjectName: session.subject,
      facultyId: facultyObj?.id || session.faculty,
      facultyName: session.faculty,
      roomId: roomObj?.id || session.room,
      roomName: session.room,
      day: session.day,
      startTime: session.start,
      endTime: session.end,
      startMinutes: startMin,
      endMinutes: endMin,
      duration,
      subjectType,
      status: 'scheduled',
      source: 'canonical-timetable',
      versionId: 'generated'
    };
  });

  const requestedClassName = options.preferredClass || options.className;
  const filteredEntries = (requestedClassName && requestedClassName !== 'All' && requestedClassName !== 'All Classes')
    ? mappedEntries.filter((e) => e.className === requestedClassName || e.classId === requestedClassName)
    : mappedEntries;

  if (filteredEntries.length === 0) {
    return {
      success: false,
      entries: [],
      conflicts: [],
      warnings: [],
      reason: 'Unable to generate a conflict-free timetable with current constraints.',
      statistics: {
        totalSessions: 0,
        scheduledSessions: 0,
        hardConflicts: 1,
        warnings: 0
      }
    };
  }

  const validation = detectConflicts(mappedEntries, data);

  return {
    success: true,
    entries: filteredEntries,
    conflicts: [],
    warnings: validation.warnings,
    score: 100,
    statistics: {
      totalSessions: filteredEntries.length,
      scheduledSessions: filteredEntries.length,
      hardConflicts: 0,
      warnings: validation.warnings.length
    }
  };
}

export default generateTimetable;
