export const classList = [
  { id: 1, name: 'S1 A BCA', department: 'Computer Applications', semester: 'ODD', section: 'A', studentCount: 60, teacher: 'Ms. Anju John' },
  { id: 2, name: 'S1 B BCA', department: 'Computer Applications', semester: 'ODD', section: 'B', studentCount: 60, teacher: 'Ms. Kavitha S' },
  { id: 3, name: 'S3 BCA', department: 'Computer Applications', semester: 'ODD', section: 'BCA', studentCount: 60, teacher: 'Ms. Sreelakshmi K S' },
  { id: 4, name: 'S5 BCA', department: 'Computer Applications', semester: 'ODD', section: 'BCA', studentCount: 60, teacher: 'Ms. Ambily Sajeev' },
  { id: 5, name: 'S1 MCA', department: 'Computer Applications', semester: 'ODD', section: 'MCA', studentCount: 60, teacher: 'Ms. Ashwani Vijayachandran' },
  { id: 6, name: 'S3 MCA', department: 'Computer Applications', semester: 'ODD', section: 'MCA', studentCount: 60, teacher: 'Ms. Athira R Kurup' }
];

