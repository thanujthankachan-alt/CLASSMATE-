export const roomList = [
  { id: 'room-n101', number: 'N 101', name: 'S1 A BCA Classroom', building: 'Main Block', type: 'Classroom', capacity: 60, availability: 'Monday-Friday', status: 'Assigned' },
  { id: 'room-n102', number: 'N 102', name: 'S1 B BCA Classroom', building: 'Main Block', type: 'Classroom', capacity: 60, availability: 'Monday-Friday', status: 'Assigned' },
  { id: 'room-n208', number: 'N 208', name: 'S1 MCA Classroom', building: 'Main Block', type: 'Classroom', capacity: 60, availability: 'Monday-Friday', status: 'Assigned' },
  { id: 'room-n209', number: 'N 209', name: 'S3 BCA Classroom', building: 'Main Block', type: 'Classroom', capacity: 60, availability: 'Monday-Friday', status: 'Assigned' },
  { id: 'room-n306', number: 'N 306', name: 'S3 MCA Classroom', building: 'Main Block', type: 'Classroom', capacity: 60, availability: 'Monday-Friday', status: 'Assigned' },
  { id: 'room-n308', number: 'N 308', name: 'S5 BCA Classroom', building: 'Main Block', type: 'Classroom', capacity: 60, availability: 'Monday-Friday', status: 'Assigned' },
  { id: 'room-lab-1', number: 'Computer Lab', name: 'Central Computer Lab', building: 'Lab Block', type: 'Lab', isLab: true, capacity: 60, availability: 'Monday-Friday', status: 'Assigned' }
];

