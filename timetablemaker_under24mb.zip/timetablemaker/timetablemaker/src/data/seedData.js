import { classList } from './classData.js';
import { facultyList } from './facultyData.js';
import { roomList } from './roomData.js';
import { subjectList } from './subjectData.js';
import { studentList } from './studentData.js';
import { slotList } from './timeSlotData.js';
import { constraintList } from './constraintData.js';
import { generateTimetable } from '../services/schedulerService.js';

const baseAppData = {
  faculty: facultyList,
  subjects: subjectList,
  rooms: roomList,
  classes: classList,
  students: studentList,
  timeSlots: slotList,
  constraints: constraintList,
  breaks: []
};

// Generate an unconflicted initial timetable preserving master details
const initialGeneration = generateTimetable(baseAppData, { className: 'All' });

export const seedAppData = {
  ...baseAppData,
  settings: {
    academicYear: '2026-2027',
    defaultSlots: '09:00 AM - 10:00 AM, 10:00 AM - 11:00 AM',
    notifications: true,
    theme: 'Light'
  },
  profile: {
    fullName: 'Admin User',
    email: 'admin@classmate.edu',
    department: 'Administration'
  },
  generatedTimetable: initialGeneration?.entries || [],
  lastGeneratedClass: 'All',
  versions: [],
  importedTimetables: []
};

