import { facultyList } from './facultyData.js';

const periods = [
  { start: '09:00', end: '09:55' },
  { start: '09:55', end: '10:50' },
  { start: '11:00', end: '11:55' },
  { start: '11:55', end: '12:45' },
  { start: '13:30', end: '14:20' },
  { start: '14:20', end: '15:10' },
  { start: '15:20', end: '16:10' }
];

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

const facultyByCourse = {
  'S1 MCA': {
    MATHS: ['Ms. Viji V'],
    DFCA: ['Mr. Eldhose K Paul', 'Ms. Ashwani Vijayachandran'],
    ADS: ['Ms. Ashwani Vijayachandran', 'Mr. Eldhose K Paul'],
    ASE: ['Ms. Divya S B', 'Ms. Athira R Kurup'],
    'PG LAB': ['Ms. Sahira Salih', 'Mr. Ajesh Avirah'],
    'WP LAB': ['Mr. Eldhose K Paul', 'Mr. Ajesh Avirah'],
    'DS LAB': ['Ms. Ashwani Vijayachandran', 'Mr. Ajesh Avirah'],
    'EP&IT': ['Mr. Ajesh Avirah'],
    PLACEMENT: ['Ms. Athira R Kurup', 'Ms. Anjaly Sajeev', 'Ms. Silpa Prem']
  },
  'S3 MCA': {
    'DS & ML': ['Ms. Divya S B', 'Dr. Eduru Nagarathna'],
    DAA: ['Ms. Athira R Kurup', 'Dr. Ramnath Rawat'],
    'CS&CP': ['Ms. Ashwani Vijayachandran', 'Dr. Ramnath Rawat'],
    IOT: ['Mr. Eldhose K Paul', 'Banu Sumayya S'],
    'DS LAB': ['Ms. Kavitha S', 'Mr. Ajesh Avirah'],
    'MOBILE APP LAB': ['Ms. Anju John', 'Mr. Ajesh Avirah'],
    'MINI PROJECT': ['Ms. Athira R Kurup', 'Ms. Divya S B'],
    'Domain Expert': ['Ms. Athira R Kurup', 'Ms. Divya S B', 'Ms. Sahira Salih'],
    PLACEMENT: ['Ms. Athira R Kurup', 'Ms. Anjaly Sajeev', 'Ms. Silpa Prem']
  },
  'S1 A BCA': {
    ENGLISH: ['Ms. Aleena Shaju'],
    MATHS: ['Ms. Reena Paul'],
    'BM&FA': ['Ms. Sreelakshmi K S', 'Ms. Anjaly Sajeev'],
    DLD: ['Ms. Sreelakshmi K S', 'Ms. Sahira Salih'],
    C: ['Ms. Anju John', 'Dr. Eduru Nagarathna'],
    'C LAB': ['Ms. Anju John', 'Ms. Sreelakshmi Sabu'],
    'LINUX LAB': ['Ms. Kavitha S', 'Ms. Sreelakshmi K S'],
    NASSCOM: ['Ms. Sreelakshmi K S', 'Ms. Sreelakshmi Sabu'],
    PLACEMENT: ['Ms. Silpa Prem', 'Ms. Anjaly Sajeev', 'Ms. Athira R Kurup']
  },
  'S1 B BCA': {
    ENGLISH: ['Ms. Aleena Shaju'],
    MATHS: ['Ms. Reena Paul'],
    'BM&FA': ['Ms. Anjaly Sajeev', 'Ms. Sreelakshmi K S'],
    DLD: ['Ms. Sahira Salih', 'Ms. Sreelakshmi Sabu'],
    C: ['Ms. Sahira Salih', 'Ms. Sreelakshmi Sabu'],
    'C LAB': ['Ms. Sahira Salih', 'Ms. Kavitha S'],
    'LINUX LAB': ['Ms. Kavitha S', 'Ms. Sahira Salih'],
    NASSCOM: ['Ms. Sreelakshmi K S', 'Ms. Sreelakshmi Sabu'],
    PLACEMENT: ['Ms. Silpa Prem', 'Ms. Anjaly Sajeev', 'Ms. Athira R Kurup']
  },
  'S3 BCA': {
    MATHS: ['Mr. Naveen Thomas'],
    OS: ['Ms. Kavitha S', 'Mr. Ramnath Rawat'],
    DAA: ['Ms. Sreelakshmi K S', 'Ms. Silpa Prem'],
    DBMS: ['Ms. Anjaly Sajeev', 'Ms. Kavitha S'],
    'UI/UX': ['Ms. Sreelakshmi K S', 'Ms. Anjaly Sajeev'],
    'UI/UX LAB': ['Ms. Sreelakshmi K S', 'Ms. Anjaly Sajeev'],
    IPR: ['Ms. Minnu VB', 'Ms. Divya S B'],
    'DBMS LAB': ['Ms. Anjaly Sajeev', 'Ms. Silpa Prem'],
    PLACEMENT: ['Ms. Anjaly Sajeev', 'Ms. Silpa Prem', 'Ms. Athira R Kurup']
  },
  'S5 BCA': {
    'AI&ML': ['Ms. Ambily Sajeev', 'Ms. Minnu VB'],
    SPM: ['Ms. Minnu VB', 'Ms. Ambily Sajeev'],
    OR: ['Ms. Rekha PR'],
    MADL: ['Ms. Minnu VB', 'Ms. Ambily Sajeev'],
    'ML LAB': ['Ms. Ambily Sajeev', 'Ms. Minnu VB'],
    'MINI PROJECT': ['Ms. Ambily Sajeev'],
    PLACEMENT: ['Ms. Anjaly Sajeev', 'Ms. Athira R Kurup', 'Ms. Silpa Prem']
  }
};

const classes = [
  {
    name: 'S1 MCA',
    department: 'Computer Applications',
    semester: 'ODD',
    room: 'N 208',
    entries: [
      [0, 1, 1, 'DFCA(T)', 'DFCA'],
      [0, 2, 2, 'DS LAB(T)', 'DS LAB'],
      [0, 3, 3, 'WP LAB(T)', 'WP LAB'],
      [0, 4, 4, 'ASE(R)', 'ASE'],
      [0, 5, 6, 'DS LAB(T)', 'DS LAB'],
      [0, 7, 7, 'PG LAB(T)', 'PG LAB'],

      [1, 1, 1, 'MATHS', 'MATHS'],
      [1, 2, 2, 'EP&IT', 'EP&IT'],
      [1, 3, 3, 'DFCA(T)', 'DFCA'],
      [1, 4, 4, 'ASE(T)', 'ASE'],
      [1, 5, 5, 'ADS', 'ADS'],
      [1, 6, 6, 'DFCA(R)', 'DFCA'],
      [1, 7, 7, 'MATHS', 'MATHS'],

      [2, 1, 3, 'PG LAB / MENTORING', 'PG LAB'],
      [2, 4, 4, 'ASE', 'ASE'],
      [2, 5, 5, 'MATHS(T)', 'MATHS'],
      [2, 6, 6, 'ADS', 'ADS'],
      [2, 7, 7, 'DFCA', 'DFCA'],

      [3, 1, 1, 'ADS(T)', 'ADS'],
      [3, 2, 2, 'DFCA', 'DFCA'],
      [3, 3, 3, 'MATHS', 'MATHS'],
      [3, 4, 4, 'ADS', 'ADS'],
      [3, 5, 5, 'ASE', 'ASE'],
      [3, 6, 6, 'MATHS(R)', 'MATHS'],
      [3, 7, 7, 'ASE', 'ASE'],

      [4, 1, 1, 'PLACEMENT', 'PLACEMENT'],
      [4, 2, 2, 'ADS(R)', 'ADS'],
      [4, 3, 4, 'WP LAB / MENTORING', 'WP LAB'],
      [4, 5, 5, 'ASE', 'ASE'],
      [4, 6, 6, 'ADS', 'ADS'],
      [4, 7, 7, 'DFCA', 'DFCA']
    ]
  },
  {
    name: 'S3 MCA',
    department: 'Computer Applications',
    semester: 'ODD',
    room: 'N 306',
    entries: [
      [0, 1, 3, 'MOBILE APP LAB / MENTORING', 'MOBILE APP LAB'],
      [0, 4, 4, 'CS&CP(R)', 'CS&CP'],
      [0, 5, 5, 'DS & ML', 'DS & ML'],
      [0, 6, 6, 'MINI PROJECT', 'MINI PROJECT'],
      [0, 7, 7, 'PLACEMENT', 'PLACEMENT'],

      [1, 1, 1, 'IOT(T)', 'IOT'],
      [1, 2, 2, 'PLACEMENT', 'PLACEMENT'],
      [1, 3, 3, 'IOT', 'IOT'],
      [1, 4, 4, 'CS&CP', 'CS&CP'],
      [1, 5, 5, 'DS&ML', 'DS & ML'],
      [1, 6, 6, 'MINI PROJECT', 'MINI PROJECT'],
      [1, 7, 7, 'IOT', 'IOT'],

      [2, 1, 1, 'DAA(T)', 'DAA'],
      [2, 2, 2, 'CS & CP', 'CS&CP'],
      [2, 3, 3, 'DAA(R)', 'DAA'],
      [2, 4, 4, 'Domain Expert', 'Domain Expert'],
      [2, 5, 5, 'DS&ML', 'DS & ML'],
      [2, 6, 6, 'DAA', 'DAA'],
      [2, 7, 7, 'MINI PROJECT', 'MINI PROJECT'],

      [3, 1, 1, 'CS&CP(T)', 'CS&CP'],
      [3, 2, 2, 'DS LAB(T)', 'DS LAB'],
      [3, 3, 4, 'DS LAB / MENTORING', 'DS LAB'],
      [3, 5, 5, 'DS&ML', 'DS & ML'],
      [3, 6, 6, 'DAA', 'DAA'],
      [3, 7, 7, 'DS&ML(R)', 'DS & ML'],

      [4, 1, 1, 'DS & ML (T)', 'DS & ML'],
      [4, 2, 2, 'DAA', 'DAA'],
      [4, 3, 3, 'IOT(R)', 'IOT'],
      [4, 4, 4, 'CS&CP', 'CS&CP'],
      [4, 5, 5, 'CS&CP', 'CS&CP'],
      [4, 6, 6, 'MINI PROJECT', 'MINI PROJECT'],
      [4, 7, 7, 'DS&ML(R)', 'DS & ML']
    ]
  },
  {
    name: 'S1 A BCA',
    department: 'Computer Applications',
    semester: 'ODD',
    room: 'N 101',
    entries: [
      [0, 1, 1, 'ENGLISH', 'ENGLISH'],
      [0, 2, 2, 'BM&FA(T)', 'BM&FA'],
      [0, 3, 3, 'MATHS', 'MATHS'],
      [0, 4, 4, 'C', 'C'],
      [0, 5, 6, 'C / LINUX LAB / MENTORING', 'C LAB'],
      [0, 7, 7, 'BM&FA', 'BM&FA'],

      [1, 1, 1, 'MATHS(T)', 'MATHS'],
      [1, 2, 2, 'BM&FA', 'BM&FA'],
      [1, 3, 3, 'ENGLISH', 'ENGLISH'],
      [1, 4, 4, 'ENGLISH', 'ENGLISH'],
      [1, 5, 5, 'DLD(R)', 'DLD'],
      [1, 6, 6, 'BM&FA', 'BM&FA'],
      [1, 7, 7, 'C', 'C'],

      [2, 1, 1, 'DLD(T)', 'DLD'],
      [2, 2, 2, 'C', 'C'],
      [2, 3, 3, 'MATHS(R)', 'MATHS'],
      [2, 4, 4, 'DLD', 'DLD'],
      [2, 5, 6, 'C / LINUX LAB / MENTORING', 'LINUX LAB'],
      [2, 7, 7, 'C(R)', 'C'],

      [3, 1, 1, 'C(T)', 'C'],
      [3, 2, 2, 'DLD', 'DLD'],
      [3, 3, 3, 'MATHS', 'MATHS'],
      [3, 4, 4, 'MATHS', 'MATHS'],
      [3, 5, 5, 'DLD', 'DLD'],
      [3, 6, 6, 'PLACEMENT / LIBRARY', 'PLACEMENT'],
      [3, 7, 7, 'PLACEMENT', 'PLACEMENT'],

      [4, 1, 1, 'C', 'C'],
      [4, 2, 2, 'DLD', 'DLD'],
      [4, 3, 3, 'NASSCOM', 'NASSCOM'],
      [4, 4, 4, 'MATHS', 'MATHS'],
      [4, 5, 5, 'ENGLISH', 'ENGLISH'],
      [4, 6, 6, 'BM&FA', 'BM&FA'],
      [4, 7, 7, 'BM&FA(R)', 'BM&FA']
    ]
  },
  {
    name: 'S1 B BCA',
    department: 'Computer Applications',
    semester: 'ODD',
    room: 'N 102',
    entries: [
      [0, 1, 1, 'DLD(T)', 'DLD'],
      [0, 2, 2, 'MATHS', 'MATHS'],
      [0, 3, 3, 'BM&FA', 'BM&FA'],
      [0, 4, 4, 'BM&FA', 'BM&FA'],
      [0, 5, 5, 'C', 'C'],
      [0, 6, 6, 'BM&FA(R)', 'BM&FA'],
      [0, 7, 7, 'NASSCOM', 'NASSCOM'],

      [1, 1, 1, 'DLD', 'DLD'],
      [1, 2, 2, 'C', 'C'],
      [1, 3, 3, 'PLACEMENT / LIBRARY', 'PLACEMENT'],
      [1, 4, 4, 'BM&FA', 'BM&FA'],
      [1, 5, 5, 'C(R)', 'C'],
      [1, 6, 6, 'ENGLISH', 'ENGLISH'],
      [1, 7, 7, 'MATHS(R)', 'MATHS'],

      [2, 1, 1, 'ENGLISH', 'ENGLISH'],
      [2, 2, 2, 'BM&FA(T)', 'BM&FA'],
      [2, 3, 3, 'PLACEMENT', 'PLACEMENT'],
      [2, 4, 4, 'ENGLISH', 'ENGLISH'],
      [2, 5, 5, 'MATHS', 'MATHS'],
      [2, 6, 6, 'MATHS', 'MATHS'],
      [2, 7, 7, 'DLD(R)', 'DLD'],

      [3, 1, 1, 'C(T)', 'C'],
      [3, 2, 2, 'C', 'C'],
      [3, 3, 3, 'DLD', 'DLD'],
      [3, 4, 4, 'DLD', 'DLD'],
      [3, 5, 6, 'C / LINUX LAB / MENTORING', 'C LAB'],
      [3, 7, 7, 'MATHS', 'MATHS'],

      [4, 1, 1, 'MATHS(T)', 'MATHS'],
      [4, 2, 2, 'ENGLISH', 'ENGLISH'],
      [4, 3, 3, 'MATHS', 'MATHS'],
      [4, 4, 4, 'C', 'C'],
      [4, 5, 6, 'C / LINUX LAB / MENTORING', 'LINUX LAB'],
      [4, 7, 7, 'DLD(R)', 'DLD']
    ]
  },
  {
    name: 'S3 BCA',
    department: 'Computer Applications',
    semester: 'ODD',
    room: 'N 209',
    entries: [
      [0, 1, 1, 'IPR', 'IPR'],
      [0, 2, 2, 'MATHS(T)', 'MATHS'],
      [0, 3, 3, 'UI/UX', 'UI/UX'],
      [0, 4, 4, 'UI/UX', 'UI/UX'],
      [0, 5, 5, 'DBMS', 'DBMS'],
      [0, 6, 6, 'MATHS(R)', 'MATHS'],
      [0, 7, 7, 'IPR(R)', 'IPR'],

      [1, 1, 2, 'UI/UX LAB / PROJECT', 'UI/UX LAB'],
      [1, 3, 3, 'MATHS', 'MATHS'],
      [1, 4, 4, 'DBMS(T)', 'DBMS'],
      [1, 5, 5, 'DAA', 'DAA'],
      [1, 6, 6, 'OS(R)', 'OS'],
      [1, 7, 7, 'UI/UX(R)', 'UI/UX'],

      [2, 1, 1, 'OS(T)', 'OS'],
      [2, 2, 2, 'UI/UX', 'UI/UX'],
      [2, 3, 3, 'IPR', 'IPR'],
      [2, 4, 4, 'DAA', 'DAA'],
      [2, 5, 5, 'UI/UX', 'UI/UX'],
      [2, 6, 6, 'MATHS', 'MATHS'],
      [2, 7, 7, 'OS', 'OS'],

      [3, 1, 1, 'OS', 'OS'],
      [3, 2, 2, 'DAA(T)', 'DAA'],
      [3, 3, 3, 'DBMS(R)', 'DBMS'],
      [3, 4, 4, 'MATHS', 'MATHS'],
      [3, 5, 5, 'DBMS', 'DBMS'],
      [3, 6, 6, 'DAA(R)', 'DAA'],
      [3, 7, 7, 'PLACEMENT', 'PLACEMENT'],

      [4, 1, 2, 'DBMS LAB / MENTORING', 'DBMS LAB'],
      [4, 3, 3, 'DAA', 'DAA'],
      [4, 4, 4, 'DBMS', 'DBMS'],
      [4, 5, 5, 'IPR(T)', 'IPR'],
      [4, 6, 6, 'DBMS', 'DBMS'],
      [4, 7, 7, 'IPR(R)', 'IPR']
    ]
  },
  {
    name: 'S5 BCA',
    department: 'Computer Applications',
    semester: 'ODD',
    room: 'N 308',
    entries: [
      [0, 1, 1, 'AI&ML(T)', 'AI&ML'],
      [0, 2, 2, 'SPM', 'SPM'],
      [0, 3, 3, 'OR', 'OR'],
      [0, 4, 4, 'SPM(R)', 'SPM'],
      [0, 5, 7, 'MINI PROJECT / MENTORING', 'MINI PROJECT'],

      [1, 1, 1, 'OR(T)', 'OR'],
      [1, 2, 2, 'SPM', 'SPM'],
      [1, 3, 3, 'PLACEMENT / LIBRARY', 'PLACEMENT'],
      [1, 4, 4, 'AI&ML', 'AI&ML'],
      [1, 5, 6, 'MOBILE APP LAB / PROJECT', 'MADL'],
      [1, 7, 7, 'AI&ML(R)', 'AI&ML'],

      [2, 1, 1, 'MADL', 'MADL'],
      [2, 2, 2, 'AI&ML', 'AI&ML'],
      [2, 3, 3, 'OR', 'OR'],
      [2, 4, 4, 'SPM', 'SPM'],
      [2, 5, 5, 'PLACEMENT / MOOC', 'PLACEMENT'],
      [2, 6, 6, 'MADL(R)', 'MADL'],
      [2, 7, 7, 'PLACEMENT', 'PLACEMENT'],

      [3, 1, 2, 'ML LAB / MENTORING', 'ML LAB'],
      [3, 3, 4, 'PLACEMENT / LIBRARY', 'PLACEMENT'],
      [3, 5, 5, 'MADL(R)', 'MADL'],
      [3, 6, 6, 'OR', 'OR'],
      [3, 7, 7, 'AI&ML', 'AI&ML'],

      [4, 1, 1, 'SPM(T)', 'SPM'],
      [4, 2, 2, 'AI&ML', 'AI&ML'],
      [4, 3, 3, 'MADL', 'MADL'],
      [4, 4, 4, 'OR(R)', 'OR'],
      [4, 5, 7, 'MINI PROJECT / MENTORING', 'MINI PROJECT']
    ]
  }
];

function toMinutes(time) {
  const [hour, minute] = time.split(':').map(Number);
  return hour * 60 + minute;
}

function overlaps(first, second) {
  return first.dayIndex === second.dayIndex
    && first.startMinutes < second.endMinutes
    && second.startMinutes < first.endMinutes;
}

function hasResourceConflict(first, second) {
  return first.className === second.className
    || first.room === second.room
    || first.faculty === second.faculty;
}

function makeSessions() {
  const facultyNames = new Set(facultyList.map((faculty) => faculty.name));
  const missingFaculty = [...new Set(Object.values(facultyByCourse).flatMap((courses) => (
    Object.values(courses).flat()
  )))].filter((name) => !facultyNames.has(name));

  if (missingFaculty.length > 0) {
    throw new Error(`Faculty missing from Faculty Management: ${missingFaculty.join(', ')}.`);
  }

  const sessions = classes.flatMap((classData) => classData.entries.map(
    ([dayIndex, firstPeriod, lastPeriod, subject, course]) => {
      const start = periods[firstPeriod - 1].start;
      const end = periods[lastPeriod - 1].end;
      const facultyOptions = facultyByCourse[classData.name]?.[course];

      if (!facultyOptions) {
        throw new Error(`No faculty mapping was provided for ${course} in ${classData.name}.`);
      }

      const isLab = !String(subject || '').endsWith('(T)') && (
        String(subject || '').toLowerCase().includes('lab') || String(course || '').toLowerCase().includes('lab')
      );
      const assignedRoom = isLab ? 'Computer Lab' : classData.room;

      return {
        className: classData.name,
        department: classData.department,
        semester: classData.semester,
        room: assignedRoom,
        dayIndex,
        day: days[dayIndex],
        start,
        end,
        startMinutes: toMinutes(start),
        endMinutes: toMinutes(end),
        subject,
        facultyOptions
      };
    }
  ));

  sessions.sort((first, second) => (
    first.dayIndex - second.dayIndex
    || first.startMinutes - second.startMinutes
    || first.className.localeCompare(second.className)
  ));

  for (const session of sessions) {
    const availableFaculty = session.facultyOptions.find((faculty) => (
      !sessions.some((other) => (
        other.faculty === faculty
        && overlaps(session, other)
      ))
    ));

    if (!availableFaculty) {
      throw new Error(
        `No conflict-free faculty is available for ${session.className} ${session.subject} on ${session.day} at ${session.start}.`
      );
    }

    session.faculty = availableFaculty;
  }

  return sessions;
}

export function getSourceTimetableConflicts() {
  const sessions = makeSessions();
  const conflicts = [];

  for (let index = 0; index < sessions.length; index += 1) {
    for (let nextIndex = index + 1; nextIndex < sessions.length; nextIndex += 1) {
      const first = sessions[index];
      const second = sessions[nextIndex];
      if (overlaps(first, second) && hasResourceConflict(first, second)) {
        const type = first.className === second.className
          ? 'Class Conflict'
          : first.room === second.room
            ? 'Room Conflict'
            : 'Faculty Conflict';
        conflicts.push({
          id: `${first.className}-${second.className}-${first.day}-${first.start}`,
          type,
          detail: type === 'Class Conflict' ? first.className : type === 'Room Conflict' ? first.room : first.faculty,
          time: `${first.day} ${first.start}–${first.end}`,
          classes: `${first.className} / ${second.className}`,
          status: 'Conflict'
        });
      }
    }
  }

  return conflicts;
}

export const sourceTimetableClasses = classes.map(({ name, department, semester, room }) => ({
  name,

  department,
  semester,
  room
}));

export const sourceTimetableNotes = [
  'Saturday remedial, SDP, department activities and MOOC course are shown without a time in the source, so they are not assigned a timed slot.',
  'Central Computer Lab is shared across all BCA and MCA classes. Lab slots have been assigned to dedicated, non-overlapping periods to resolve lab room collisions.'
];

export function generateSourceTimetable(className) {
  const classData = sourceTimetableClasses.find((item) => item.name === className);
  if (!classData) {
    throw new Error(`No timetable input was found for ${className}.`);
  }

  return makeSessions()
    .filter((session) => session.className === className)
    .map(({ facultyOptions, startMinutes, endMinutes, dayIndex, ...session }) => session);
}

export function validateSourceTimetables() {
  const conflicts = getSourceTimetableConflicts();
  if (conflicts.length > 0) {
    throw new Error(`Schedule conflicts were found: ${conflicts.map((item) => item.time).join(', ')}.`);
  }
  return true;
}

export function getAllSourceTimetableSessions() {
  return makeSessions().map(({ facultyOptions, startMinutes, endMinutes, ...session }) => session);
}
