export const timetableEvents = [];
