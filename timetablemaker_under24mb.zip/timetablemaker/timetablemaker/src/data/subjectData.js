export const subjectList = [
  // S1 MCA
  { id: '20MCA101', code: '20MCA101', name: 'Mathematical Foundations For Computing', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Viji V', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: '20MCA103', code: '20MCA103', name: 'Digital Fundamentals & Computer Architecture', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Mr. Eldhose K Paul / Ms. Ashwani Vijayachandran', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: '20MCA105', code: '20MCA105', name: 'Advanced Data Structures', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Ashwani Vijayachandran / Mr. Eldhose K Paul', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: '20MCA107', code: '20MCA107', name: 'Advanced Software Engineering', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Athira R Kurup / Ms. Divya S B', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: '20MCA131', code: '20MCA131', name: 'Programming Lab', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Lab', faculty: 'Ms. Sahira Salih / Mr. Ajesh Avirah', duration: 3, weeklyPeriods: 1, requiresLab: true },
  { id: '20MCA133', code: '20MCA133', name: 'Web Programming Lab', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Lab', faculty: 'Mr. Eldhose K Paul / Mr. Ajesh Avirah', duration: 2, weeklyPeriods: 1, requiresLab: true },
  { id: '20MCA135', code: '20MCA135', name: 'Data Structures Lab', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Lab', faculty: 'Ms. Ashwani Vijayachandran / Mr. Ajesh Avirah', duration: 3, weeklyPeriods: 1, requiresLab: true },
  { id: '20MCANC1', code: '20MCANC1', name: 'Entrepreneurship & Innovations In Technology', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Theory', faculty: 'Mr. Ajesh Avirah', duration: 1, weeklyPeriods: 1, requiresLab: false },

  // S3 MCA
  { id: '20MCA201', code: '20MCA201', name: 'Data Science & Machine Learning', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Divya S B / Dr. Eduru Nagarathna', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: '20MCA203', code: '20MCA203', name: 'Design & Analysis Of Algorithms', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Athira R Kurup / Dr. Ramnath Rawat', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: '20MCA263', code: '20MCA263', name: 'Cyber Security & Cryptography', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Ashwani Vijayachandran / Dr. Ramnath Rawat', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: '20MCA281', code: '20MCA281', name: 'Internet Of Things', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Mr. Eldhose K Paul / Banu Sumayya S', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: '20MCA241', code: '20MCA241', name: 'Data Science Lab', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Lab', faculty: 'Ms. Kavitha S / Mr. Ajesh Avirah', duration: 2, weeklyPeriods: 1, requiresLab: true },
  { id: '20MCA243', code: '20MCA243', name: 'Mobile Application Development Lab', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Lab', faculty: 'Ms. Anju John / Mr. Ajesh Avirah', duration: 2, weeklyPeriods: 1, requiresLab: true },
  { id: '20MCA245', code: '20MCA245', name: 'Mini Project', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Project', faculty: 'Ms. Athira R Kurup', duration: 1, weeklyPeriods: 4, requiresLab: false },

  // S1 BCA
  { id: 'BCAET101', code: 'BCAET101', name: 'Professional English', department: 'Computer Applications', semester: 'ODD', credits: '3', sessionType: 'Theory', faculty: 'Ms. Aleena Shaju', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: 'BCPCT102', code: 'BCPCT102', name: 'Foundational Mathematics', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Reena Paul', duration: 1, weeklyPeriods: 5, requiresLab: false },
  { id: 'BCMDT103', code: 'BCMDT103', name: 'Business Management & Fundamentals of Accountancy', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Sreelakshmi K S / Ms. Anjaly Sajeev', duration: 1, weeklyPeriods: 5, requiresLab: false },
  { id: 'BCPCT104', code: 'BCPCT104', name: 'Digital Electronics & Logic Designs', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Sreelakshmi K S / Ms. Sahira Salih', duration: 1, weeklyPeriods: 5, requiresLab: false },
  { id: 'BCPCT105', code: 'BCPCT105', name: 'Structured Programming Using C', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Anju John / Ms. Sahira Salih', duration: 1, weeklyPeriods: 5, requiresLab: false },
  { id: 'BCPCL106', code: 'BCPCL106', name: 'Structured Programming Lab', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Lab', faculty: 'Ms. Anju John / Ms. Sahira Salih', duration: 2, weeklyPeriods: 1, requiresLab: true },
  { id: 'BCPCL107', code: 'BCPCL107', name: 'Linux Lab', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Lab', faculty: 'Ms. Sreelakshmi K S / Ms. Kavitha S', duration: 2, weeklyPeriods: 1, requiresLab: true },
  { id: 'NASSCOM', code: 'NASSCOM', name: 'NASSCOM Course', department: 'Computer Applications', semester: 'ODD', credits: '1', sessionType: 'Activity', faculty: 'Ms. Sreelakshmi K S', duration: 1, weeklyPeriods: 1, requiresLab: false },

  // S3 BCA
  { id: 'BCPCT301', code: 'BCPCT301', name: 'Statistical and Numerical Methods', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Mr. Naveen Thomas', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: 'BCPCT302', code: 'BCPCT302', name: 'Operating Systems', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Kavitha S / Mr. Ramnath Rawat', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: 'BCPCT303', code: 'BCPCT303', name: 'Design And Analysis of Algorithms', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Sreelakshmi K S / Ms. Silpa Prem', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: 'BCPCT304', code: 'BCPCT304', name: 'Database Management Systems', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Anjaly Sajeev / Ms. Kavitha S', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: 'BCPBT306', code: 'BCPBT306', name: 'UI and UX Design Lab', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Lab', faculty: 'Ms. Sreelakshmi K S / Ms. Anjaly Sajeev', duration: 2, weeklyPeriods: 1, requiresLab: true },
  { id: 'BCAET306', code: 'BCAET306', name: 'Engineering Entrepreneurship & IPR', department: 'Computer Applications', semester: 'ODD', credits: '3', sessionType: 'Theory', faculty: 'Ms. Minnu VB / Ms. Divya S B', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: 'BCPCL307', code: 'BCPCL307', name: 'Database Management Systems Lab', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Lab', faculty: 'Ms. Anjaly Sajeev / Ms. Silpa Prem', duration: 2, weeklyPeriods: 1, requiresLab: true },

  // S5 BCA
  { id: 'BCPCT501', code: 'BCPCT501', name: 'Artificial Intelligence and Machine Learning', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Ambily Sajeev / Ms. Minnu VB', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: 'BCPET513', code: 'BCPET513', name: 'Operation Research', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Rekha PR', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: 'BCPCT521', code: 'BCPCT521', name: 'Software Project Management', department: 'Computer Applications', semester: 'ODD', credits: '4', sessionType: 'Theory', faculty: 'Ms. Minnu VB / Ms. Ambily Sajeev', duration: 1, weeklyPeriods: 4, requiresLab: false },
  { id: 'BCPBT504', code: 'BCPBT504', name: 'Mobile Application Development Lab', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Lab', faculty: 'Ms. Minnu VB / Ms. Ambily Sajeev', duration: 2, weeklyPeriods: 1, requiresLab: true },
  { id: 'BCPCL505', code: 'BCPCL505', name: 'Machine Learning Lab', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Lab', faculty: 'Ms. Ambily Sajeev / Ms. Minnu VB', duration: 2, weeklyPeriods: 1, requiresLab: true },
  { id: 'BCPCP506', code: 'BCPCP506', name: 'Mini Project - 1', department: 'Computer Applications', semester: 'ODD', credits: '2', sessionType: 'Project', faculty: 'Ms. Ambily Sajeev', duration: 1, weeklyPeriods: 4, requiresLab: false },

  // Common
  { id: 'PLACEMENT', code: 'PLACEMENT', name: 'Placement', department: 'Computer Applications', semester: 'ODD', credits: '1', sessionType: 'Activity', faculty: 'Ms. Athira R Kurup / Ms. Anjaly Sajeev / Ms. Silpa Prem', duration: 1, weeklyPeriods: 1, requiresLab: false }
];

