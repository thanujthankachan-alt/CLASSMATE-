import { useState } from 'react';
import { Plus, Pencil, Trash2, ToggleLeft, ToggleRight, Check, X, Shield, Clock, MapPin, User, Info } from 'lucide-react';
import ToastMessage from '../components/ToastMessage.jsx';
import { useAppData } from '../hooks/useAppData.js';

const CATEGORIES = [
  'General',
  'Lab Priority & Single Lab Restriction',
  'Faculty Workload & Availability',
  'Room Capacity & Availability',
  'Break Periods & Lunch',
  'Class Schedule & Timetable Bounds'
];

function Constraints() {
  const [constraints, setConstraints] = useAppData('constraints');
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newCategory, setNewCategory] = useState(CATEGORIES[0]);
  const [toast, setToast] = useState(null);

  // Edit Modal State
  const [editingItem, setEditingItem] = useState(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editActive, setEditActive] = useState(true);

  const handleAdd = () => {
    if (!newTitle.trim()) return;
    const newItem = {
      id: Date.now(),
      title: newTitle,
      description: newDescription || 'Standard timetable constraint rule.',
      category: newCategory,
      active: true
    };
    setConstraints([newItem, ...constraints]);
    setNewTitle('');
    setNewDescription('');
    setToast('New constraint added successfully');
  };

  const handleOpenEdit = (item) => {
    setEditingItem(item);
    setEditTitle(item.title);
    setEditDescription(item.description || '');
    setEditCategory(item.category || CATEGORIES[0]);
    setEditActive(item.active !== false);
  };

  const handleSaveEdit = (e) => {
    e.preventDefault();
    if (!editingItem || !editTitle.trim()) return;

    setConstraints(
      constraints.map((c) =>
        c.id === editingItem.id
          ? {
              ...c,
              title: editTitle,
              description: editDescription,
              category: editCategory,
              active: editActive
            }
          : c
      )
    );

    setEditingItem(null);
    setToast('Constraint updated successfully');
  };

  const toggleActive = (item) => {
    setConstraints(
      constraints.map((constraint) =>
        constraint.id === item.id ? { ...constraint, active: !constraint.active } : constraint
      )
    );
    setToast(`Constraint "${item.title}" ${item.active ? 'disabled' : 'enabled'}`);
  };

  const handleDelete = (item) => {
    if (window.confirm(`Delete constraint "${item.title}"?`)) {
      setConstraints(constraints.filter((constraint) => constraint.id !== item.id));
      setToast('Constraint deleted');
    }
  };

  return (
    <div className="constraints-page">
      <div className="d-flex flex-column flex-md-row align-items-start align-items-md-center justify-content-between gap-3 mb-4">
        <div>
          <h4 className="mb-1">Constraint Management</h4>
          <p className="text-muted mb-0">
            Define, edit, and manage constraints for DCA single computer lab allocation, room capacity, faculty limits, and schedules.
          </p>
        </div>

        {/* Add Constraint Quick Card */}
        <div className="card p-3 border-0 shadow-sm bg-white" style={{ minWidth: 340 }}>
          <h6 className="mb-3 fw-bold d-flex align-items-center gap-2">
            <Plus size={18} className="text-primary" /> Add New Constraint
          </h6>
          <div className="mb-2">
            <label className="form-label small fw-semibold">Constraint Title</label>
            <input
              className="form-control form-control-sm"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="e.g. DCA Single Computer Lab Conflict Rules"
            />
          </div>
          <div className="mb-2">
            <label className="form-label small fw-semibold">Category</label>
            <select
              className="form-select form-select-sm"
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value)}
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label className="form-label small fw-semibold">Description</label>
            <textarea
              className="form-control form-control-sm"
              value={newDescription}
              onChange={(e) => setNewDescription(e.target.value)}
              rows="2"
              placeholder="Enter constraint details and enforcement rules"
            />
          </div>
          <button className="btn btn-primary btn-sm w-100 fw-semibold" onClick={handleAdd}>
            <Plus size={16} className="me-1" /> Save Constraint
          </button>
        </div>
      </div>

      {/* Constraint List Cards */}
      <div className="row g-3">
        {constraints.map((item) => (
          <div className="col-md-6" key={item.id}>
            <div className={`card shadow-sm border-0 h-100 ${item.active ? '' : 'bg-light bg-opacity-50'}`}>
              <div className="card-body d-flex flex-column justify-content-between p-4">
                <div>
                  <div className="d-flex justify-content-between align-items-start mb-2">
                    <div>
                      <span className="badge bg-light text-dark border me-2 small" style={{ fontSize: '0.72rem' }}>
                        {item.category || 'General'}
                      </span>
                      <h5 className="mb-1 mt-1 fw-bold">{item.title}</h5>
                    </div>
                    <span className={`badge ${item.active ? 'bg-success' : 'bg-secondary'}`}>
                      {item.active ? 'Enabled' : 'Disabled'}
                    </span>
                  </div>
                  <p className="text-muted small mb-3">{item.description}</p>
                </div>

                <div className="d-flex gap-2 flex-wrap pt-2 border-top">
                  <button
                    className={`btn btn-sm ${item.active ? 'btn-outline-warning' : 'btn-outline-success'}`}
                    onClick={() => toggleActive(item)}
                  >
                    {item.active ? <ToggleRight size={15} className="me-1" /> : <ToggleLeft size={15} className="me-1" />}
                    {item.active ? 'Disable' : 'Enable'}
                  </button>
                  <button className="btn btn-sm btn-outline-primary" onClick={() => handleOpenEdit(item)}>
                    <Pencil size={15} className="me-1" /> Edit
                  </button>
                  <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(item)}>
                    <Trash2 size={15} className="me-1" /> Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Constraint Modal */}
      {editingItem && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(15, 23, 42, 0.65)', backdropFilter: 'blur(4px)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
              <div className="modal-header bg-dark text-white p-3">
                <h5 className="modal-title fw-bold d-flex align-items-center gap-2">
                  <Pencil size={18} className="text-primary" /> Edit Constraint
                </h5>
                <button type="button" className="btn-close btn-close-white" onClick={() => setEditingItem(null)} aria-label="Close" />
              </div>

              <form onSubmit={handleSaveEdit}>
                <div className="modal-body p-4">
                  <div className="mb-3">
                    <label className="form-label fw-semibold">Constraint Title</label>
                    <input
                      className="form-control"
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label fw-semibold">Category</label>
                    <select
                      className="form-select"
                      value={editCategory}
                      onChange={(e) => setEditCategory(e.target.value)}
                    >
                      {CATEGORIES.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="mb-3">
                    <label className="form-label fw-semibold">Description & Rules</label>
                    <textarea
                      className="form-control"
                      value={editDescription}
                      onChange={(e) => setEditDescription(e.target.value)}
                      rows="4"
                      required
                    />
                  </div>

                  <div className="form-check form-switch mb-2">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="editActiveToggle"
                      checked={editActive}
                      onChange={(e) => setEditActive(e.target.checked)}
                    />
                    <label className="form-check-label fw-semibold" htmlFor="editActiveToggle">
                      Constraint Enabled
                    </label>
                  </div>
                </div>

                <div className="modal-footer bg-light p-3">
                  <button type="button" className="btn btn-secondary" onClick={() => setEditingItem(null)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary fw-semibold px-4">
                    <Check size={16} className="me-1" /> Save Changes
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {toast && <ToastMessage message={toast} onClose={() => setToast(null)} />}
    </div>
  );
}

export default Constraints;
