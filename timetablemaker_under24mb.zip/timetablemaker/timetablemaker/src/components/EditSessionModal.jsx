import React, { useState, useMemo } from 'react';
import { X, CheckCircle, AlertTriangle, Save, Trash2, Clock, MapPin, User, BookOpen, Laptop } from 'lucide-react';
import { detectConflicts } from '../services/conflictService.js';
import { timeToMinutes, format12HourRange } from '../utils/timeUtils.js';

const WEEK_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

const TIME_SLOTS = [
  { start: '09:00', end: '09:55', label: 'Period 1 (09:00 - 09:55)' },
  { start: '09:55', end: '10:50', label: 'Period 2 (09:55 - 10:50)' },
  { start: '11:00', end: '11:55', label: 'Period 3 (11:00 - 11:55)' },
  { start: '11:55', end: '12:45', label: 'Period 4 (11:55 - 12:45)' },
  { start: '13:30', end: '14:20', label: 'Period 5 (01:30 PM - 02:20 PM)' },
  { start: '14:20', end: '15:10', label: 'Period 6 (02:20 PM - 03:10 PM)' },
  { start: '15:20', end: '16:10', label: 'Period 7 (03:20 PM - 04:10 PM)' },

  // Lab Blocks (3 to 4 periods continuous)
  { start: '09:00', end: '11:55', label: 'Morning Lab Block (09:00 - 11:55 • 3 Periods)' },
  { start: '09:00', end: '12:45', label: 'Morning 4-Period Block (09:00 - 12:45)' },
  { start: '13:30', end: '16:10', label: 'Afternoon Lab Block (01:30 PM - 04:10 PM • 3 Periods)' }
];

function EditSessionModal({ session, appState, onSave, onDelete, onClose }) {
  const classes = appState.classes || [];
  const subjects = appState.subjects || [];
  const faculty = appState.faculty || [];
  const rooms = appState.rooms || [];

  const isNew = !session || !session.id;

  const [selectedClassId, setSelectedClassId] = useState(() => {
    if (session?.classId) return String(session.classId);
    if (session?.className) return classes.find((c) => c.name === session.className)?.id || classes[0]?.id || '';
    return classes[0]?.id || '';
  });

  const [selectedSubjectId, setSelectedSubjectId] = useState(() => {
    if (session?.subjectId) return String(session.subjectId);
    if (session?.subjectName) return subjects.find((s) => s.name === session.subjectName || s.code === session.subjectName)?.id || subjects[0]?.id || '';
    return subjects[0]?.id || '';
  });

  const [selectedFacultyId, setSelectedFacultyId] = useState(() => {
    if (session?.facultyId) return String(session.facultyId);
    if (session?.facultyName) return faculty.find((f) => f.name === session.facultyName)?.id || faculty[0]?.id || '';
    return faculty[0]?.id || '';
  });

  const [selectedRoomId, setSelectedRoomId] = useState(() => {
    if (session?.roomId) return String(session.roomId);
    if (session?.roomName) return rooms.find((r) => r.number === session.roomName || r.name === session.roomName)?.id || rooms[0]?.id || '';
    return rooms[0]?.id || '';
  });

  const [day, setDay] = useState(session?.day || 'Monday');
  const [startTime, setStartTime] = useState(session?.startTime || '09:00');
  const [endTime, setEndTime] = useState(session?.endTime || '09:55');

  // Available subjects filtered by class
  const classSubjects = useMemo(() => {
    const activeClass = classes.find((c) => String(c.id) === String(selectedClassId));
    if (!activeClass) return subjects;
    return subjects.filter((s) => {
      if (s.classId && String(s.classId) === String(activeClass.id)) return true;
      if (s.className && s.className === activeClass.name) return true;
      const cName = (activeClass.name || '').toUpperCase();
      const sCode = (s.code || '').toUpperCase();
      if (cName.includes('MCA') && sCode.startsWith('20MCA')) return true;
      if (cName.includes('BCA') && (sCode.startsWith('BCA') || sCode.startsWith('BCP') || sCode.startsWith('BCM') || sCode === 'NASSCOM')) return true;
      return true;
    });
  }, [classes, subjects, selectedClassId]);

  // When class changes, update subject
  const handleClassChange = (newClassId) => {
    setSelectedClassId(newClassId);
    const firstSub = subjects.find((s) => String(s.classId) === String(newClassId));
    if (firstSub) {
      setSelectedSubjectId(firstSub.id);
    }
  };

  // When subject changes, update default faculty/room
  const handleSubjectChange = (newSubjectId) => {
    setSelectedSubjectId(newSubjectId);
    const sub = subjects.find((s) => String(s.id) === String(newSubjectId));
    if (sub) {
      if (sub.requiresLab || sub.sessionType === 'Lab' || (sub.name || '').toLowerCase().includes('lab')) {
        const labRoom = rooms.find((r) => r.isLab || r.type === 'Lab');
        if (labRoom) setSelectedRoomId(labRoom.id);
        // Default lab duration block if 09:00 start
        if (startTime === '09:00' && endTime === '09:55') {
          setEndTime('11:55');
        }
      }
    }
  };

  const handleSlotChange = (e) => {
    const val = e.target.value;
    const found = TIME_SLOTS.find((s) => `${s.start}-${s.end}` === val);
    if (found) {
      setStartTime(found.start);
      setEndTime(found.end);
    }
  };

  // Live conflict evaluation
  const liveConflictValidation = useMemo(() => {
    const classObj = classes.find((c) => String(c.id) === String(selectedClassId));
    const subjectObj = subjects.find((s) => String(s.id) === String(selectedSubjectId));
    const facultyObj = faculty.find((f) => String(f.id) === String(selectedFacultyId));
    const roomObj = rooms.find((r) => String(r.id) === String(selectedRoomId));

    const updatedEntry = {
      id: session?.id || `entry-temp-${Date.now()}`,
      classId: selectedClassId,
      className: classObj?.name || 'Class',
      subjectId: selectedSubjectId,
      subjectName: subjectObj?.name || subjectObj?.code || 'Subject',
      facultyId: selectedFacultyId,
      facultyName: facultyObj?.name || 'Faculty',
      roomId: selectedRoomId,
      roomName: roomObj?.number || roomObj?.name || 'Room',
      day,
      startTime,
      endTime,
      startMinutes: timeToMinutes(startTime),
      endMinutes: timeToMinutes(endTime),
      subjectType: (subjectObj?.requiresLab || subjectObj?.sessionType === 'Lab') ? 'Lab' : 'Theory'
    };

    // Filter out existing session if updating
    const remainingEntries = (appState.generatedTimetable || []).filter((s) => s.id !== session?.id);
    const testEntries = [...remainingEntries, updatedEntry];

    const validation = detectConflicts(testEntries, appState);
    const relevantConflicts = validation.hardConflicts.filter((c) => {
      return (
        c.entryIds?.includes(updatedEntry.id) ||
        (c.day === day && c.startTime === startTime)
      );
    });

    return {
      isValid: relevantConflicts.length === 0,
      conflicts: relevantConflicts,
      updatedEntry
    };
  }, [session, selectedClassId, selectedSubjectId, selectedFacultyId, selectedRoomId, day, startTime, endTime, classes, subjects, faculty, rooms, appState]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(liveConflictValidation.updatedEntry);
  };

  return (
    <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(15, 23, 42, 0.65)', backdropFilter: 'blur(4px)' }}>
      <div className="modal-dialog modal-dialog-centered modal-lg">
        <div className="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
          <div className="modal-header bg-dark text-white p-3">
            <h5 className="modal-title fw-bold d-flex align-items-center gap-2">
              {isNew ? <BookOpen size={18} className="text-primary" /> : <Laptop size={18} className="text-info" />}
              {isNew ? 'Add Timetable Session' : 'Edit Timetable Session'}
            </h5>
            <button type="button" className="btn-close btn-close-white" onClick={onClose} aria-label="Close" />
          </div>

          <form onSubmit={handleSubmit}>
            <div className="modal-body p-4">
              {/* Live Conflict Status Banner */}
              <div className={`alert ${liveConflictValidation.isValid ? 'alert-success' : 'alert-danger'} d-flex align-items-center justify-content-between p-3 mb-4 rounded-3 border`}>
                <div className="d-flex align-items-center gap-2">
                  {liveConflictValidation.isValid ? (
                    <CheckCircle size={20} className="text-success" />
                  ) : (
                    <AlertTriangle size={20} className="text-danger animate-bounce" />
                  )}
                  <div>
                    <div className="fw-bold" style={{ fontSize: '0.9rem' }}>
                      {liveConflictValidation.isValid ? 'Unconflicted Slot' : 'Conflict Detected!'}
                    </div>
                    <div className="small" style={{ fontSize: '0.8rem' }}>
                      {liveConflictValidation.isValid
                        ? 'This session time and room allocation is completely safe.'
                        : liveConflictValidation.conflicts[0]?.message}
                    </div>
                  </div>
                </div>
                <span className={`badge ${liveConflictValidation.isValid ? 'bg-success' : 'bg-danger'} px-2 py-1`}>
                  {liveConflictValidation.isValid ? 'VALID' : `${liveConflictValidation.conflicts.length} ISSUES`}
                </span>
              </div>

              <div className="row g-3">
                {/* Class */}
                <div className="col-md-6">
                  <label className="form-label fw-semibold">Class</label>
                  <select
                    className="form-select"
                    value={selectedClassId}
                    onChange={(e) => handleClassChange(e.target.value)}
                    required
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.department})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Subject */}
                <div className="col-md-6">
                  <label className="form-label fw-semibold">Subject</label>
                  <select
                    className="form-select"
                    value={selectedSubjectId}
                    onChange={(e) => handleSubjectChange(e.target.value)}
                    required
                  >
                    {classSubjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.code} - {s.name} {s.requiresLab ? '[LAB]' : ''}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Faculty */}
                <div className="col-md-6">
                  <label className="form-label fw-semibold">Faculty</label>
                  <select
                    className="form-select"
                    value={selectedFacultyId}
                    onChange={(e) => setSelectedFacultyId(e.target.value)}
                    required
                  >
                    {faculty.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.name} ({f.department || 'DCA'})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Room */}
                <div className="col-md-6">
                  <label className="form-label fw-semibold">Room / Lab</label>
                  <select
                    className="form-select"
                    value={selectedRoomId}
                    onChange={(e) => setSelectedRoomId(e.target.value)}
                    required
                  >
                    {rooms.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.number || r.name} {r.isLab || r.type === 'Lab' ? '💻 [Computer Lab]' : '🏫 [Classroom]'}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Day */}
                <div className="col-md-4">
                  <label className="form-label fw-semibold">Day</label>
                  <select className="form-select" value={day} onChange={(e) => setDay(e.target.value)} required>
                    {WEEK_DAYS.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Slot Preset */}
                <div className="col-md-8">
                  <label className="form-label fw-semibold">Time Slot Preset</label>
                  <select className="form-select" onChange={handleSlotChange}>
                    <option value="">-- Choose Preset Period or Lab Block --</option>
                    {TIME_SLOTS.map((slot) => (
                      <option key={`${slot.start}-${slot.end}`} value={`${slot.start}-${slot.end}`}>
                        {slot.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Custom Start & End */}
                <div className="col-md-6">
                  <label className="form-label small text-muted">Start Time (HH:MM)</label>
                  <input
                    type="time"
                    className="form-control"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    required
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label small text-muted">End Time (HH:MM)</label>
                  <input
                    type="time"
                    className="form-control"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    required
                  />
                </div>
              </div>
            </div>

            <div className="modal-footer bg-light p-3 d-flex align-items-center justify-content-between">
              <div>
                {!isNew && onDelete && (
                  <button
                    type="button"
                    className="btn btn-outline-danger"
                    onClick={() => onDelete(session.id)}
                  >
                    <Trash2 size={15} className="me-1" /> Delete Session
                  </button>
                )}
              </div>
              <div className="d-flex align-items-center gap-2">
                <button type="button" className="btn btn-secondary" onClick={onClose}>
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`btn ${liveConflictValidation.isValid ? 'btn-primary' : 'btn-warning'} fw-semibold px-4`}
                >
                  <Save size={16} className="me-1" /> Save Session
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default EditSessionModal;
