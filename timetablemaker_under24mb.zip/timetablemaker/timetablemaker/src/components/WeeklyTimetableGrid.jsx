import React, { useMemo, useState } from 'react';
import { format12HourRange } from '../utils/timeUtils.js';
import { BookOpen, Laptop, User, MapPin, Coffee, Utensils, AlertTriangle, Plus, Edit2, Maximize2, Minimize2 } from 'lucide-react';

const DEFAULT_PERIODS = [
  { id: 1, label: 'Period 1', start: '09:00', end: '09:55' },
  { id: 2, label: 'Period 2', start: '09:55', end: '10:50' },
  { id: 3, label: 'Period 3', start: '11:00', end: '11:55' },
  { id: 4, label: 'Period 4', start: '11:55', end: '12:45' },
  { id: 'lunch', label: 'Lunch', start: '12:45', end: '13:30', isBreak: true, icon: 'lunch' },
  { id: 5, label: 'Period 5', start: '13:30', end: '14:20' },
  { id: 6, label: 'Period 6', start: '14:20', end: '15:10' },
  { id: 7, label: 'Period 7', start: '15:20', end: '16:10' }
];

const WEEK_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

function toMin(timeStr = '') {
  const [h, m] = String(timeStr).trim().split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

function WeeklyTimetableGrid({
  sessions = [],
  className = '',
  onSessionClick,
  onEditSession,
  onAddSession,
  conflicts = [],
  isEditMode = false,
  highlightConflictsOnly = false,
  defaultCompact = true
}) {
  const [isCompact, setIsCompact] = useState(defaultCompact);

  const days = useMemo(() => {
    const sessionDays = [...new Set(sessions.map((s) => s.day).filter(Boolean))];
    const ordered = WEEK_DAYS.filter((d) => sessionDays.includes(d));
    if (sessionDays.includes('Saturday') && !ordered.includes('Saturday')) {
      ordered.push('Saturday');
    }
    return ordered.length > 0 ? ordered : WEEK_DAYS;
  }, [sessions]);

  // Conflict lookup helper for a session
  const getSessionConflict = (session) => {
    if (!conflicts || conflicts.length === 0 || !session) return null;
    return conflicts.find((c) => {
      if (Array.isArray(c.entryIds) && c.entryIds.includes(session.id)) return true;
      if (c.day === session.day && c.startTime === session.startTime) {
        if (c.classId && String(c.classId) === String(session.classId || session.className)) return true;
        if (c.type === 'LAB_OVERLAP' || c.type === 'ROOM_OVERLAP') return true;
        if (c.type === 'FACULTY_OVERLAP' && String(c.facultyId) === String(session.facultyId)) return true;
      }
      return false;
    });
  };

  const getCardStyle = (subject = '', type = '', conflict = null) => {
    if (conflict) {
      return {
        bg: 'linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%)',
        border: '#ef4444',
        text: '#991b1b',
        badgeBg: '#dc2626',
        badgeText: '#ffffff',
        tag: conflict.type === 'LAB_OVERLAP' ? 'LAB CONFLICT' : 'CONFLICT',
        isConflict: true
      };
    }

    const subLower = subject.toLowerCase();
    const typeLower = (type || '').toLowerCase();

    if (subLower.includes('lab') || typeLower.includes('lab')) {
      return {
        bg: 'linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%)',
        border: '#0284c7',
        text: '#0369a1',
        badgeBg: '#0284c7',
        badgeText: '#ffffff',
        tag: 'LAB'
      };
    }
    if (subLower.includes('placement') || subLower.includes('project') || subLower.includes('mentor')) {
      return {
        bg: 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)',
        border: '#16a34a',
        text: '#15803d',
        badgeBg: '#16a34a',
        badgeText: '#ffffff',
        tag: 'ACTIVITY'
      };
    }
    if (subLower.includes('(t)') || subLower.includes('tutorial')) {
      return {
        bg: 'linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%)',
        border: '#d97706',
        text: '#b45309',
        badgeBg: '#d97706',
        badgeText: '#ffffff',
        tag: 'TUTORIAL'
      };
    }
    if (subLower.includes('(r)') || subLower.includes('remedial')) {
      return {
        bg: 'linear-gradient(135deg, #fdf2f8 0%, #fce7f3 100%)',
        border: '#db2777',
        text: '#be185d',
        badgeBg: '#db2777',
        badgeText: '#ffffff',
        tag: 'REMEDIAL'
      };
    }
    return {
      bg: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)',
      border: '#6366f1',
      text: '#4338ca',
      badgeBg: '#4f46e5',
      badgeText: '#ffffff',
      tag: 'CORE'
    };
  };

  const cardMinHeight = isCompact ? 50 : 80;

  return (
    <div className="weekly-grid-container table-responsive rounded-4 border bg-white shadow-sm p-2">
      {/* Density Control Toolbar */}
      <div className="d-flex align-items-center justify-content-between mb-2 px-1 no-print">
        <span className="small text-muted fw-semibold" style={{ fontSize: '0.75rem' }}>
          Screen Fit Density: <strong className="text-dark">{isCompact ? 'Compact Screen Fit' : 'Expanded View'}</strong>
        </span>
        <button
          type="button"
          className="btn btn-xs btn-outline-secondary py-1 px-2 d-flex align-items-center gap-1"
          style={{ fontSize: '0.72rem' }}
          onClick={() => setIsCompact(!isCompact)}
        >
          {isCompact ? <Maximize2 size={12} /> : <Minimize2 size={12} />}
          {isCompact ? 'Expand Row Height' : 'Make Screen Short'}
        </button>
      </div>

      <table className="table table-bordered align-middle mb-0 text-center" style={{ minWidth: 920 }}>
        <thead>
          <tr className="bg-light text-dark">
            <th style={{ width: 95, background: '#1e293b', color: '#fff', fontSize: '0.78rem' }} className="py-2 fw-bold align-middle">
              Day / Period
            </th>
            {DEFAULT_PERIODS.map((period) => (
              <th
                key={period.id}
                style={{
                  background: period.isBreak ? '#f8fafc' : '#f1f5f9',
                  color: period.isBreak ? '#64748b' : '#1e293b',
                  fontSize: '0.78rem',
                  minWidth: period.isBreak ? 48 : 110
                }}
                className="py-1.5 align-middle"
              >
                <div className="fw-bold">{period.label}</div>
                <div className="small text-muted fw-normal" style={{ fontSize: '0.7rem' }}>
                  {format12HourRange(period.start, period.end)}
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {days.map((day) => {
            const daySessions = sessions.filter((s) => s.day === day);
            const renderedSlots = [];

            for (let i = 0; i < DEFAULT_PERIODS.length; i++) {
              const period = DEFAULT_PERIODS[i];

              if (period.isBreak) {
                renderedSlots.push(
                  <td
                    key={`${day}-${period.id}`}
                    style={{
                      background: 'repeating-linear-gradient(45deg, #f8fafc, #f8fafc 6px, #f1f5f9 6px, #f1f5f9 12px)',
                      color: '#94a3b8',
                      writingMode: 'vertical-rl',
                      textOrientation: 'mixed',
                      fontSize: '0.65rem',
                      fontWeight: 600,
                      padding: '2px 1px'
                    }}
                    className="align-middle text-uppercase"
                  >
                    <div className="d-flex align-items-center justify-content-center gap-1 mx-auto">
                      {period.icon === 'lunch' ? <Utensils size={11} /> : <Coffee size={11} />}
                      <span>{period.label}</span>
                    </div>
                  </td>
                );
                continue;
              }

              const pStartMin = toMin(period.start);
              const pEndMin = toMin(period.end);

              const session = daySessions.find((s) => {
                const sStart = toMin(s.startTime || s.start);
                const sEnd = toMin(s.endTime || s.end);
                return sStart < pEndMin && sEnd > pStartMin;
              });

              if (!session) {
                renderedSlots.push(
                  <td key={`${day}-${period.id}`} className="p-1 align-middle bg-light bg-opacity-25">
                    {isEditMode ? (
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-primary w-100 py-1 border-dashed"
                        style={{ borderStyle: 'dashed', fontSize: '0.68rem' }}
                        onClick={() => onAddSession && onAddSession(day, period)}
                      >
                        <Plus size={11} className="me-1" /> Add
                      </button>
                    ) : (
                      <div className="text-muted small opacity-50 fst-italic" style={{ fontSize: '0.7rem' }}>
                        — Free —
                      </div>
                    )}
                  </td>
                );
                continue;
              }

              const sStart = toMin(session.startTime || session.start);
              if (sStart < pStartMin - 5) {
                continue;
              }

              const sEnd = toMin(session.endTime || session.end);
              let colSpan = 1;
              while (i + 1 < DEFAULT_PERIODS.length) {
                const nextPeriod = DEFAULT_PERIODS[i + 1];
                if (!nextPeriod.isBreak && sEnd > toMin(nextPeriod.start) + 15) {
                  colSpan++;
                  i++;
                } else {
                  break;
                }
              }

              const subjectName = session.subjectName || session.subject || 'Subject';
              const facultyName = session.facultyName || session.faculty || 'Faculty';
              const roomName = session.roomName || session.room || 'Room';
              const sessionClassName = session.className || session.class || className;
              const conflict = getSessionConflict(session);
              const style = getCardStyle(subjectName, session.type || session.subjectType, conflict);
              const isLab = style.tag === 'LAB' || (subjectName.toLowerCase().includes('lab'));

              renderedSlots.push(
                <td
                  key={`${day}-${session.startTime}-${session.subject}-${session.id || i}`}
                  colSpan={colSpan}
                  className="p-1 align-middle"
                  style={{ verticalAlign: 'middle' }}
                >
                  <div
                    onClick={() => {
                      if (isEditMode && onEditSession) {
                        onEditSession(session);
                      } else if (onSessionClick) {
                        onSessionClick(session);
                      }
                    }}
                    className={`h-100 rounded-2 text-start transition-all cursor-pointer shadow-sm border ${
                      isCompact ? 'px-2 py-1' : 'p-2'
                    } ${conflict ? 'animate-pulse' : ''}`}
                    style={{
                      background: style.bg,
                      borderColor: style.border,
                      borderLeftWidth: conflict ? 5 : 3,
                      minHeight: cardMinHeight,
                      cursor: 'pointer',
                      boxShadow: conflict ? '0 0 8px rgba(239, 68, 68, 0.35)' : undefined
                    }}
                    title={conflict ? conflict.message : subjectName}
                  >
                    <div className="d-flex align-items-center justify-content-between mb-0.5">
                      <span
                        className="badge px-1 py-0 fw-semibold"
                        style={{
                          background: style.badgeBg,
                          color: style.badgeText,
                          fontSize: '0.62rem'
                        }}
                      >
                        {conflict ? (
                          <span className="d-flex align-items-center gap-1">
                            <AlertTriangle size={9} /> {style.tag}
                          </span>
                        ) : colSpan > 1 ? (
                          `${colSpan}H ${style.tag}`
                        ) : (
                          style.tag
                        )}
                      </span>

                      <div className="d-flex align-items-center gap-1">
                        {isEditMode && (
                          <span className="badge bg-primary text-white px-1 py-0" style={{ fontSize: '0.6rem' }}>
                            <Edit2 size={9} />
                          </span>
                        )}
                        <span className="badge bg-white text-dark border px-1 py-0 fw-normal" style={{ fontSize: '0.62rem' }}>
                          <MapPin size={9} className="me-0.5 text-secondary d-inline" />
                          {roomName}
                        </span>
                      </div>
                    </div>

                    <div
                      className="fw-bold text-truncate"
                      style={{ color: style.text || '#0f172a', fontSize: isCompact ? '0.78rem' : '0.84rem', lineHeight: 1.2 }}
                    >
                      {isLab ? <Laptop size={11} className="me-1 text-primary d-inline" /> : <BookOpen size={11} className="me-1 text-indigo d-inline" />}
                      {subjectName}
                    </div>

                    {!isCompact && sessionClassName && sessionClassName !== className && className !== 'All' && (
                      <div className="small fw-semibold text-secondary" style={{ fontSize: '0.65rem' }}>
                        Class: {sessionClassName}
                      </div>
                    )}

                    <div className="d-flex align-items-center justify-content-between pt-0.5 mt-0.5 border-top border-light border-opacity-75">
                      <span className="small text-truncate text-muted d-flex align-items-center" style={{ fontSize: '0.66rem', maxWidth: 110 }} title={facultyName}>
                        <User size={10} className="me-0.5 text-muted" />
                        {facultyName}
                      </span>
                      <span className="text-muted fw-semibold" style={{ fontSize: '0.62rem' }}>
                        {format12HourRange(session.startTime || period.start, session.endTime || period.end)}
                      </span>
                    </div>

                    {conflict && (
                      <div className="mt-0.5 small fw-semibold text-danger" style={{ fontSize: '0.62rem', lineHeight: 1.1 }}>
                        ⚠️ {conflict.message}
                      </div>
                    )}
                  </div>
                </td>
              );
            }

            return (
              <tr key={day}>
                <td style={{ background: '#0f172a', color: '#f8fafc' }} className="fw-bold align-middle py-1.5 px-2">
                  <div className="text-uppercase" style={{ letterSpacing: '0.03em', fontSize: '0.78rem' }}>
                    {day}
                  </div>
                  <div className="small text-muted fw-normal" style={{ fontSize: '0.65rem' }}>
                    {daySessions.length} Classes
                  </div>
                </td>
                {renderedSlots}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default WeeklyTimetableGrid;
